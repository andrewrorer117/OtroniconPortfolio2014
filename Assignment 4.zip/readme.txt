// COP 3402 Homework #4 (PL/0 Compiler)
// Andrew Rorer
// Frank Yi


Instructions:
	To run the tiney compiler the user is first prompt to enter a file name less than 30 characters long. This file must contain source code for the PL/0 Language and the file must not end with any blank lines. If an incorrect file name is input the program will terminate, otherwise the information will be read into the Lexical Scanner. Upon completetion of the Lexical Scanner the program will have printed, to the command prompt, the original source code, a lexeme list, the lexeme lists symbolic representation, and an error analysis. When thiis program encounters an error it will omit it from the lexeme list and continue generating tokens. The error analysis printed at the end of the program will count the occurances of each error


The errors that will be checked for within Lexical Scanner are as follows:
	1. Variable does not start wth letter.
	2. Number is too long.
	3. Name is too long.
	4. Invalid symbols. 


Valid tokens are as follows:
	Reserved words: begin, end, if, then while, do, call, const, int, procedure, out, in, 	                      else, and odd.
	Special Symbols: '+', '-', '*', '/', ',', '(', ')', '[', ']',  '=', '!=', '.', '<',    		                 '<=', '>', '>=', ';', ':'
	Identifiers: letter (letter|digit)*
	Numbers: (digit)+
	Invisible Characters: tab, white spaces, newline
	Comments: /*...*/


	If errors where found during the process of creating tokens the program is aborted. Otherwise the parser will begin to run. The parser checks for 15 syntax errors these errors are as follows.


Syntax Errors:
	1. Use = instead of :=.
	2. = must be followed by a number.
	3. Identifier must be followed by =.
	4. const, var, procedure must be followed by identifier.
	5. Semicolon or comma missing.
	6. Period expected.
	7. Undeclared identifier.
	8. Assignment to constant or procedure is not allowed.
	9. Assignment operator expected.
	10. then expected.
	11. Semicolon or } expected.
	12. do expected.
	13. Relational operator expected.
	14. Right parenthesis missing.
	15. The preceding factor cannot begin with this symbol.
	16. Statement expected. 

	17. Incorrect symbol after procedure declaration.
	18. Incorrect symbol after statement part in block.
	19. 'call' must be followed by an identifier.
	20. 'call' of a constant or variable is meaningless
	21. Expression must not contain a procedure identifier. 
	22. Identifier expected after 'in' command.
	23. Identifier expected after 'out' command. 


	If one of these errors is encountered the program will be terminated. Otherwise the message "No errors, program is syntatically correct" will be printed to the command prompt and the virtual machine will begin to run. If at any time the code legth becomes greather than the maximum allowed code length the program will terminate. During this phase of the program the generated sequence code will be analyzed by the Virtual machine. If the problem counter exceeds the generated code size the program will terminate. If the problem counter exceeds the maximum code length the program terminates. Finaly the the intermediate code and the stack output from the Virtual Machine are printed to the command prompt. 


Valid OPcode instructions for this Virtual Machine are:
	FCH: this is treated as No OPcode
	LIT: Push constant value M onto stack
	OPR:
		RET: (sp <- bp - 1 and pc <- stack[sp + 3] and bp <- stack[sp + 2]
		NEG: -stack[sp]
		ADD: sp <- sp - 1 and stack[sp] <- stack[sp] + stack[sp + 1
		SUB: sp <- sp - 1 and stack[sp] <- stack[sp] - stack[sp + 1]
		MUL: sp <- sp - 1 and stack[sp] <- stack[sp] - stack[sp + 1]
		DIV: sp <- sp - 1 and stack[sp] <- stack[sp] div stack[sp + 1]
		ODD: stack[sp] <- stack mod 2) or ord(odd(stack[sp]))
		MOD: sp <- sp - 1 and stack[sp] <- stack[sp] mod stack[sp + 1
		EQL: sp <- sp - 1 and stack[sp] <- stack[sp] = =stack[sp + 1]
		NEQ: sp <- sp - 1 and stack[sp] <- stack[sp] != stack[sp + 1]
		LSS: sp <- sp - 1 and stack[sp] <- stack[sp] < stack[sp + 1]
		LEQ: sp <- sp - 1 and stack[sp] <- stack[sp] <= stack[sp + 1]
		GTR: sp <- sp - 1 and stack[sp] <- stack[sp] > stack[sp + 1]
		GEQ: sp <- sp - 1 and stack[sp] <- stack[sp] >= stack[sp + 1]
	LOD: Push from location at offset M in frame L levels down
	STO: Store in location at ofset M in frame L levels down
	CAL: Call procedure at M
	INC: Allocate M locations, first three are SL, DL, RA
	JMP: Sets PC = M
	JMC: Jump to M if top of stack element is 0 and decrement SP by one
	SIO: Preform standard IO operation, depending on L in instruction register


