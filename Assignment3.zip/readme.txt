To run the compiler name your input"inputHw3.txt" and enter the follwing commands in the console from within whatever
directory you put the compiler source files and scripts in:

	gcc "PL0 scanner.c" -o scanner
	gcc Parser.c -o parser
	gcc p-machine.c -o p-machine
	chmod u-rx compile


To run the compiler type the "./compile" after following the above steps.  Compile has 3 directives:

	-l : print the list of lexemes/tokens (scanner output) to the screen
	-a : print the generated assembly code (parser/codegen output) to the screen
	-v : print virtual machine execution trace (virtual machine output) to the screen

which can be entered in any order.
