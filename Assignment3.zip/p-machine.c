// COP 3402 Homework #3 (p-machine)
//Andrew Rorer
//Frank Yi

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STACK_HEIGHT 2000
#define MAX_CODE_LENGTH 500
#define MAX_LEXI_LEVELS 3


typedef struct
{
	int op;
	int l;
	int m;
} instruction;

//global variable declarations, global variables represent the registers
int stack[MAX_STACK_HEIGHT];
int sp = 0;
int bp = 1;
int pc = 0;


int base(int l, int base);
int top();
void push(int val);
int pop();
instruction fetch(instruction* code);
int execute(instruction ir);
void printOp(int op, FILE* file);


int main()
{
	instruction ir;
	ir.op = 0;
	ir.l = 0;
	ir.m = 0;
	instruction code[MAX_CODE_LENGTH];	//an array for storing the code from input.txt
	int lex1 = 0, lex2 = 0, lex3 = 0;
	int currLexLevel = 1;

	//set the initial stack values
	int i;
	for(i = 0; i < MAX_STACK_HEIGHT; i++)
	{
		stack[i] = 0;
	}

	FILE *in;
	in = fopen("parseOut.txt", "r");	//open the input file

	FILE *out;
	out = fopen("machineOut.txt", "w");	//open the output file

	//read the input file and store it in code[]
	int codeLength = 0;
	int eof = 0;
	for(i = 0; i < MAX_CODE_LENGTH; i++)
	{
		if(fscanf(in, "%d %d %d", &code[i].op, &code[i].l, &code[i].m) == EOF)
		{
			eof = 1;
			break;
		}

		codeLength++;
	}

	//if the file contains more than MAX_CODE_LENGTH lines of code
	if(eof != 1)
	{
		printf("Error: Maximum code length exceeded\n");
	}

	//formatting
	fprintf(out, "Line\t\tOP\t\tL\t\tM\n");

	//outputs the source code
	for(i = 0; i < codeLength; i++)
	{
		fprintf(out, "%d\t\t\t", i);
		printOp(code[i].op, out);
		fprintf(out, "\t\t%d", code[i].l);
		fprintf(out, "\t\t%d\n", code[i].m);
	}

	fprintf(out, "\t\t\t\t\t\t\t\t\t\tpc\t\tbp\t\tsp\t\tstack\n");	//print the header
	fprintf(out, "Initial values\t\t\t\t\t\t\t%d\t\t%d\t\t%d\n", pc, bp, sp);	//print initial values

	//run the virtual machine
	int lineNumber;
	instruction temp;
	while(bp != 0)
	{
		//fetch instruction, execute that instruction, shut down and print error message in case of error
		lineNumber = pc;
		temp = fetch(code);
		if(execute(temp) == 0)
		{
			printf("Fatal error: runtime error\n");
			exit(EXIT_FAILURE);
		}

		//print the current line of code
		fprintf(out, "%d\t\t\t", lineNumber);
		printOp(temp.op, out);
		fprintf(out, "\t\t%d", temp.l);
		fprintf(out, "\t\t%d", temp.m);

		//print pc, bp, and sp
		fprintf(out, "\t\t\t%d\t\t%d\t\t%d\t\t", pc, bp, sp);

		//print the stack
		for(i = 1; i <= sp; i++)
		{
			fprintf(out, " %d ", stack[i]);

			if(bp <= 1)
			{
				currLexLevel = 1;

				lex1 = -1;
				lex2 = -1;
				lex3 = -1;
			}

			if(i == (bp - 1) && bp > 1 && i != lex1 && i != lex2 && i != lex3)
			{
				switch(currLexLevel)
				{
				case 1:
					lex1 = i;
					lex2 = -1;
					lex3 = -1;
					break;

				case 2:
					lex2 = i;
					lex3 = -1;
					break;

				case 3:
					lex3 = i;
					break;
				}

				currLexLevel++;
			}

			if(i == lex1 || i == lex2 || i == lex3)
			{
				fprintf(out, " | ");
			}
		}

		//prints the activation record if the stack pointer hasn't been adjusted
		if(sp < bp + 4 && bp > 1)
		{
			for(i = bp; i < bp + 4; i++)
			{
				fprintf(out, " %d ", stack[i]);
			}

		}

		fprintf(out, "\n");
	}

	fclose(in);
	fclose(out);

	return 0;
}


//Find base L levels down
int base(int l, int base)
{
	int bl = base;

	while(l > 0)
	{
		bl = stack[bl + l];
		l--;
	}

	return bl;
}

//returns the value at the top of the stack
int top()
{
	return stack[sp];
}

//pushes a value to the top of the stack
void push(int val)
{
	if(sp == MAX_STACK_HEIGHT)
	{
		//print an error message and exit the program
		printf("Fatal error: Stack overflow\n");
		exit(EXIT_FAILURE);
	}

	sp++;
	stack[sp] = val;
}

//returns the value at the top of the stack
int pop()
{
	int val = stack[sp];
	sp--;

	return val;
}

//fetches an instruction for the execute cycle, returns that instruction
instruction fetch(instruction* code)
{
	instruction ir = code[pc];
	pc++;

	return ir;
}

//executes the instruction just fetched.  Returns 1 if successful, returns 0 if failed
int execute(instruction ir)
{
	//temporary variables for use in stack operations
	int temp, temp1, temp2;

	switch(ir.op) {

	//LIT
	case 1:
		push(ir.m);
		return 1;

	//OPR
	case 2:
		switch(ir.m) {

		//RET
		case 0:

			sp = bp - 1;		//return sp to its previous position
			pc = stack[sp + 4];	//return to the return address
			bp = stack[sp + 3];	//use the dynamic link to return bp to its previous position

			break;

		//NEG
		case 1:

			temp = -pop();
			push(temp);

			break;

		//ADD
		case 2:

			temp1 = pop();
			temp2 = pop();

			push(temp2 + temp1);

			break;

		//SUB
		case 3:

			temp1 = pop();
			temp2 = pop();

			push(temp2 - temp1);

			break;

		//MUL
		case 4:

			temp1 = pop();
			temp2 = pop();

			push(temp2 * temp1);

			break;

		//DIV
		case 5:

			temp1 = pop();
			temp2 = pop();

			push(temp2 / temp1);

			break;

		//ODD
		case 6:

			temp = pop();
			push(temp % 2);

			break;

		//MOD
		case 7:

			temp1 = pop();
			temp2 = pop();

			push(temp2 % temp1);

			break;

		//EQL
		case 8:

			temp1 = pop();
			temp2 = pop();

			push(temp2 == temp1);

			break;

		//NEQ
		case 9:

			temp1 = pop();
			temp2 = pop();

			push(temp2 != temp1);

			break;

		//LSS
		case 10:

			temp1 = pop();
			temp2 = pop();

			push(temp2 < temp1);

			break;

		//LEQ
		case 11:

			temp1 = pop();
			temp2 = pop();

			push(temp2 <= temp1);

			break;

		//GTR
		case 12:

			temp1 = pop();
			temp2 = pop();

			push(temp2 > temp1);

			break;

		//GEQ
		case 13:

			temp1 = pop();
			temp2 = pop();

			push(temp2 >= temp1);

			break;

		default:
			printf("Error: %d is not an operation for opr\n", ir.m);
			return 0;
		}

		return 1;

	//LOD
	case 3:
		push(stack[base(ir.l, bp) + ir.m]);
		return 1;

	//STO
	case 4:
		stack[base(ir.l, bp) + ir.m] = pop();
		return 1;

	//CAL
	case 5:

		push(0);				//space to return value
		push(base(ir.l, bp));	//static link (SL)
		push(bp);				//dynamic link (DL)
		push(pc);				//return address (RA)

		//subtract 4 from sp to return sp to previous value
		sp -= 4;

		//set bp to sp, and pc to m
		bp = sp + 1;
		pc = ir.m;

		return 1;

	//INC
	case 6:
		sp += ir.m;
		return 1;

	//JMP
	case 7:
		pc = ir.m;
		return 1;

	//JPC
	case 8:

		if(top() == 0)
		{
			pc = ir.m;
		}

		pop();
		return 1;

	//SIO
	case 9:

		//m is 1
		if(ir.m == 1)
		{
			printf("%d", pop());
		}

		//m is 2
		else
		{
			//scan in temp
			scanf("%d", &temp);

			//and push temp to the stack
			push(temp);
		}

		return 1;

	//SIO
	case 10:

		//m is 1
		if(ir.m == 1)
		{
			printf("%d", pop());
		}

		//m is 2
		else
		{
			//scan in temp
			scanf("%d", &temp);

			//and push temp to the stack
			push(temp);
		}

		return 1;
	}

	//if op was not found, print an error message and return 0
	printf("Error: operation %d is not a p-code operation\n", ir.op);
	return 0;
}

//print the mnemonic for the operation op to file
void printOp(int op, FILE* file)
{
	switch(op)
	{
	case 1:
		fprintf(file, "lit");
		break;

	case 2:
		fprintf(file, "opr");
		break;

	case 3:
		fprintf(file, "lod");
		break;

	case 4:
		fprintf(file, "sto");
		break;

	case 5:
		fprintf(file, "cal");
		break;

	case 6:
		fprintf(file, "inc");
		break;

	case 7:
		fprintf(file, "jmp");
		break;

	case 8:
		fprintf(file, "jpc");
		break;

	case 9:
		fprintf(file, "sio");
		break;

	case 10:
		fprintf(file, "sio");
		break;
	}
}
