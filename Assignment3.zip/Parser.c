// COP 3402 Homework #3 (Parser/Code Generator)
// Andrew Rorer
// Frank Yi

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//constants
#define MAX_SYMBOL_TABLE_SIZE 5000
#define MAX_IDENT_LENGTH 11
#define CODE_SIZE 100
#define CONST 1
#define INT 2
#define PROC 3
#define TRUE 1
#define FALSE 0
#define ERRMAX 4        // Maximum error number

//a struct for storing symbols
typedef struct{
	int kind;
	char name[MAX_IDENT_LENGTH + 1];
	int value;
	int level;
	int addr;
}symbol;

typedef struct{
    int kind;
    char name[MAX_IDENT_LENGTH + 1];
    int value;
    int hasValue;
}token;

typedef struct{
    int op;
    int l;
    int m;
} code;

char *instructions[] = {" ", "LIT", "OPR", "LOD", "STO", "CAL", "INC", "JMP", "JPC", "SIO"};
code codeStack[CODE_SIZE];
code IR;

/*
 * Start global variables
 */
symbol symbol_table[MAX_SYMBOL_TABLE_SIZE];
int currTokenLocation = 0;      // Index of array in the current token
int indexGenCodeArray = 0;      // Index of generated code array
int ctemp;                      // Temp holders for index of generated code array
int numSymbols = 0;             // Number of symbols
int incomingIdent = 3;          // Holds the address of the incoming identifiers
int varUsed;                    // Determines if a valid variable is used
int CIT;                        // Determines if valid variable is used
int cx = 0;                     // Index of generated code array
int m = 3;                      // Holds address of incoming identifiers
int h;                          // index of nameRec array
symbol tempSymbol;
symbol locTempSymbol;
token currToken;
token nameRec[1500];
int errors[ERRMAX];
int currLine = 1;
/*
 * End global variables
 */


/*
 * Start function declarations
 */
void Program();
void Block();
void Statement();
void Condition();
void Expression();
void Term();
void Factor();
symbol getSymbol();
void nextToken();
void emit();
int checkIdentType();
void printParserErrors();
void printSymbolTable();
void printGeneratedCode();
char* typeToLexeme(int type);
void updateTable(symbol temp);
void printLexemeList();
void printLexemeTable();
int printErrors();
/*
 * End function declarations
 */
char * symbolesName[] = {"", "nulsym", "identsym", "numbersym", "plussym", "minussym",
			 "multsym", "slashsym", "oddsym", "eqlsym", "neqsym", "lessym",
			 "leqsym", "grtsym", "geqsym", "lparentsym", "rparentsym", "commasym",
			 "semicolonsym", "periodsym", "becomessym", "beginsym", "endsym",
			 "ifsym", "thensym", "whilesym", "dosym", "callsym", "constsym",
			 "intsym", "procsym", "outsym", "insym", "elsesym"};

typedef enum {VARERR = 0, NUMERR, VARLENERR, SYMBERR} error_type;

enum tokenTypes	{ nulsym = 1, identsym = 2, numbersym = 3, plussym = 4, minussym = 5, multsym = 6,  slashsym = 7, oddsym = 8,  eqlsym = 9, neqsym = 10,
	lessym = 11, leqsym = 12, gtrsym = 13, geqsym = 14, lparentsym = 15, rparentsym = 16, commasym = 17, semicolonsym = 18, periodsym = 19, becomessym = 20,
	beginsym = 21, endsym = 22, ifsym = 23, thensym = 24, whilesym = 25, dosym = 26, callsym = 27, constsym = 28, intsym = 29, procsym = 30, writesym = 31,
	readsym = 32, elsesym = 33
};

enum OPCODE {FCH, LIT, OPR, LOD, STO, CAL, INC, JMP, JPC, SIO};
enum STACK_OPERATION {RET, NEG, ADD, SUB, MUL, DIV, ODD, MOD, EQL, NEQ, LSS, LEQ, GTR, GEQ};

int main ()
{
	FILE* in_fp = fopen("scannerOut.txt", "r");
	FILE* out_fp = fopen("parseOut.txt", "w");

	int numTokens = 0;
	char temp[13] = "";
	while((strcmp(temp, "Lexeme List:") != 0) && !feof(in_fp))
	{
		fgets(temp, 13, in_fp);
	}

	if(strcmp(temp, "Lexeme List:") == 0)
	{
		int currType = 0;
		while(!feof(in_fp))
		{
			fscanf(in_fp, "%d", &currType);

			if(currType == identsym || currType == numbersym)
			{
				nameRec[numTokens].kind = currType;
				fscanf(in_fp, "%s", nameRec[numTokens].name);

				//printf(" %d|%s ", nameRec[numTokens].kind, nameRec[numTokens].name);
			}

			else
			{
				nameRec[numTokens].kind = currType;
				//printf(" %d ", nameRec[numTokens].kind);
			}

			numTokens++;
		}

		Program();
		int i;
		for(i = 0; i < currLine; i++)
		{
			fprintf(out_fp, "%d %d %d\n", codeStack[i].op, codeStack[i].m, codeStack[i].l);
		}
	}

	else if(feof(in_fp))
	{
		printf("Lexeme list not found");
	}
	
	fclose(out_fp);
	fclose(in_fp);

	return 0;
}

void Program()
{
    nextToken();
    Block();
    if(currToken.kind != periodsym)
    {
        printParserErrors(9);
    }
    else
    {
        printf("\nNo errors, program is syntactically correct\n\n\n");
    }
}

//TODO: add lookahead to these functions
void Block()
{
    // If token is a constant
    if(currToken.kind == constsym)
    {
        do
        {
            symbol_table[numSymbols].kind= CONST;   // Copy type into symbol struct

            nextToken();
            if(currToken.kind != identsym)
            {
                printParserErrors(4);
                //printf("Name: %s", currToken.name);
            }

            strcpy(symbol_table[numSymbols].name, currToken.name);// Copy name into symbol struct

            nextToken();
            if(currToken.kind != eqlsym)
            {
                printParserErrors(3);
            }

            nextToken();
            if(currToken.kind != numbersym)
            {
                printParserErrors(2);
            }

            symbol_table[numSymbols].value = currToken.value; // Copy value into symbol strut
            numSymbols++;

            nextToken();
        }while(currToken.kind == commasym);

        if(currToken.kind != semicolonsym)
        {
        	printParserErrors(5);
        }

        currLine++; // UPDATE LINE
        nextToken();
    }

    if(currToken.kind == intsym)
    {
        do
        {
            symbol_table[numSymbols].kind = INT;    // Copy type into symbol_table at location numSymbols

            nextToken();
            if(currToken.kind != identsym)
            {
                printParserErrors(4);
            }

            strcpy(symbol_table[numSymbols].name, currToken.name); // Copy name into syStruct

            symbol_table[numSymbols].level = 0;
            symbol_table[numSymbols].addr = m;
            m++;
            numSymbols++;

            nextToken();
            //printf("Current token: %d\n", currToken.kind);
        }while(currToken.kind == commasym);

        if(currToken.kind != semicolonsym)
        {
        	printParserErrors(5);
        }

    	currLine++; // UPDATE LINE
        nextToken();
    }

    emit(INC, 0, m);

    // If token is a procedure
    while(currToken.kind == procsym)
    {
        symbol_table[numSymbols].kind = PROC;

        nextToken();

        if(currToken.kind != identsym)
        {
            printParserErrors(4);
        }

        nextToken();

        strcpy(symbol_table[numSymbols].name, currToken.name);
        numSymbols++;

        if(currToken.kind != semicolonsym)
        {
            printParserErrors(5);
        }

        nextToken();
        Block();

        if(currToken.kind != semicolonsym)
        {
            printParserErrors(5);
        }

        currLine++; // UPDATE LINE
        nextToken();
    }

    //printf("Current token: %d\n", currToken.kind);
    if(currToken.kind != beginsym)
    {
        printParserErrors(7);
    }

    currLine++; // UPDATE LINE
    Statement();
}


void Statement()
{
    int currM, i;
    symbol locTempSymbol;

    //TODO: ask Frank about this segment of code
    if(currToken.kind == identsym)
    {
        // Checks if variable is in the symbol table
        CIT = checkIdentType();
        if(CIT == CONST || CIT == PROC)
        {
        	printParserErrors(12);
        }
        if(CIT == 0)
        {
        	printParserErrors(11);
        }
        // Stores current symbol
        locTempSymbol = getSymbol();

        nextToken();
    if(currToken.kind != becomessym)
    {
        if(currToken.kind == eqlsym)
        {
            printParserErrors(1);
        }
        printParserErrors(13);
    }

    nextToken();
    Expression();

    // Store symbol and update symbol table
    emit(STO, 0, locTempSymbol.addr);
    updateTable(locTempSymbol);

    }

    else if(currToken.kind == callsym)
    {
        nextToken();
        if(currToken.kind != identsym)
        {
            printParserErrors(14);
            // check if identifier is on symbol table
        }

        CIT = checkIdentType();

        if(CIT == CONST || CIT == INT)
        {
            printParserErrors(15);
        }

        if(CIT == 0)
        {
            printParserErrors(11);
        }

        nextToken();
    }

    else if(currToken.kind == beginsym)
    {
        nextToken();
        Statement();

        while(currToken.kind == semicolonsym)
        {
            currLine++; // UPDATE LINE
            nextToken();
            Statement();
        }

        if(currToken.kind != endsym)
        {
            printParserErrors(17);
        }

        currLine++;
        nextToken();
    }

    else if(currToken.kind == ifsym)
    {
        nextToken();
        Condition();

        if(currToken.kind != thensym)
        {
            printParserErrors(16);
        }
        else
        {
            nextToken();
        }

        currLine++;
        ctemp = cx;
        emit(JPC, 0, 0);                // OPcode for jump
        Statement();
        codeStack[ctemp].m = cx;
    }

    else if(currToken.kind == whilesym)
    {
        nextToken();
        int currM = cx;
        Condition();
        if(currToken.kind != dosym)
        {
            printParserErrors(18);
        }

        currLine++;
        nextToken();
        ctemp = cx;     // ctemp + 1 is after JPC
        emit(JPC, 0, 0);
        Statement();
        emit(JMP, 0, currM);
        codeStack[ctemp].m = cx;
    }
}

void Condition()
{
    int relatop;
    if(currToken.kind == oddsym)
    {
        relatop = currToken.kind;
        nextToken();
        Expression();

        if(relatop == oddsym)
        {
            emit(OPR, 0, ODD);
        }
    }

    else{
        Expression();
                // Double check this par. Pseudo code is asking if TOKEN != RELATION
                // TODO: This area is giving trouble,
        if(currToken.kind != gtrsym && currToken.kind != geqsym &&
            currToken.kind != lessym && currToken.kind != leqsym &&
            currToken.kind != eqlsym && currToken.kind != neqsym)
        {
                printParserErrors(20);
        }

        else
        {
            if(currToken.kind == gtrsym)
            {
                relatop = gtrsym;
            }

            else if(currToken.kind == geqsym)
            {
                relatop = geqsym;
            }

            else if(currToken.kind == lessym)
            {
                relatop = lessym;
            }

            else if(currToken.kind == leqsym)
            {
                relatop = leqsym;
            }

            else if(currToken.kind == eqlsym)
            {
                relatop = eqlsym;
            }

            else if(currToken.kind == neqsym)
            {
                relatop = neqsym;
            }
        }
        nextToken();
        Expression();

        if(relatop == gtrsym)
        {
            emit(OPR, 0, GTR);
        }
        else if(relatop == geqsym)
        {
            emit(OPR, 0, GEQ);
        }
        else if(relatop == lessym)
        {
            emit(OPR, 0, LSS);
        }
        else if(relatop== leqsym)
        {
            emit(OPR, 0, LEQ);
        }
        else if(relatop == eqlsym)
        {
            emit(OPR, 0, EQL);
        }
        else if(relatop == neqsym)
        {
            emit(OPR, 0, NEQ);
        }
    }
}

void Expression()
{
    int addop;
    if(currToken.kind == plussym || currToken.kind == minussym)
    {
        addop = currToken.kind;

        nextToken();
        Term();

        if(addop == minussym)
        {
            emit(OPR, 0, NEG);// negate
        }
    }
    else
    {
        Term();
    }

    while(currToken.kind == plussym || currToken.kind == minussym)
    {
        addop = currToken.kind;
        nextToken();
        Term();

        if(addop == plussym)
        {
            emit(OPR, 0, ADD);      // addition
        }

        else
        {
            emit(OPR, 0, SUB);      // subtraction
        }
    }
}

void Term ()
{
    int mulop;
    Factor();
    while(currToken.kind == multsym || currToken.kind == slashsym)
    {
        mulop = currToken.kind;
        nextToken();
        Factor();
        if(mulop == multsym)
        {
            emit(OPR, 0, MUL);      // multiply
        }

        else
        {
            emit(OPR, 0, DIV);      // divide
        }
    }
}

void Factor()
{
    if(currToken.kind == identsym)
    {
        CIT = checkIdentType();

        if(CIT == CONST)
        {
        	emit(LIT, 0, tempSymbol.value);
        }

        else if(CIT == INT)
        {
        	emit(LOD, 0, tempSymbol.addr);
        }

        else if(CIT == PROC)
        {
        	printParserErrors(21);
        }

        else if(CIT == 0)
        {
        	printParserErrors(11);
        }

        nextToken();
        //printf("Current token: %d\n", currToken.kind);
    }

    else if(currToken.kind == numbersym)
    {
        emit(LIT, 0, currToken.value);
        nextToken();
    }

    else if(currToken.kind == lparentsym)
    {
        nextToken();
        Expression();

        if(currToken.kind != rparentsym)
        {
            printParserErrors(22);
        }

        nextToken();
    }

    else
    {
        printParserErrors(23);
    }
}


symbol getSymbol()
{
	symbol emptySymbol;
	emptySymbol.addr = 0;
	emptySymbol.kind = 0;
	emptySymbol.level = 0;
	strcpy(emptySymbol.name, "");
	emptySymbol.value = 0;

    int i = 0;
    for(i = 0; i < numSymbols; i ++)
    {
        if(strcmp(currToken.name, symbol_table[i].name) == 0)
        {
            return symbol_table[i];
        }
    }

    return emptySymbol;
}

void nextToken()
{
    currToken = nameRec[currTokenLocation];
    currTokenLocation++;
}

void emit(int op, int l, int m)
{
    if (cx > CODE_SIZE)
    {
        printParserErrors(25);
    }

    else
    {
        codeStack[cx].op = op;
        codeStack[cx].l = l;
        codeStack[cx].m = m;
        cx++;
    }
}

int checkIdentType()
{
    int i;
    for(i = 0; i < numSymbols; i++)
    {
        if(strcmp(currToken.name, symbol_table[i].name) == 0)
        {
            tempSymbol = symbol_table[i];
            return symbol_table[i].kind;
        }
    }

    return 0; // This means symbol was not found
}

void printParserErrors(int errorNum)
{
    switch(errorNum)
    {
        case 1: printf("Use = instead of :=.\n");
            break;

        case 2: printf("= must be followed by a number.\n");
            break;

        case 3: printf("Identifier must be followed by =.\n");
            break;

        case 4: printf("const, var, procedure must be followed by identifier.\n");
            break;

        case 5: printf("Semicolon or comma missing.\n");
            break;

        case 6: printf("Incorrect symbol after procedure declaration.\n");
            break;

        case 7: printf("Statement expected.\n");
            break;

        case 8: printf("Incorrect symbol after statement part in block.\n");
            break;

        case 9: printf("Period expected.\n");
            break;

        case 10: printf("Semicolon between statements missing.\n");
            break;

        case 11: printf("Undeclared identifier.\n");
            break;

        case 12: printf("Assignment to constant or procedure is not allowed.\n");
            break;

        case 13: printf("Assignment operator expected.\n");
            break;

        case 14: printf("call must be followed by an identifier.\n");
            break;

        case 15: printf("Call of a constant or variable is meaningless.\n");
            break;

        case 16: printf("then expected.\n");
            break;

        case 17: printf("Semicolon or } expected.\n");
            break;

        case 18: printf("do expected.\n");
            break;

        case 19: printf("Incorrect symbol following statement.\n");
            break;

        case 20: printf("Relational operation expected.\n");
            break;

        case 21: printf("Expression must not contain a procedure identifier.\n");
            break;

        case 22: printf("Right parenthesis missing.\n");
            break;

        case 23: printf("The preceding factor cannot being with this symbol.\n");
            break;

        case 24: printf("An expression cannot begin with this symbol.\n");
            break;

        case 25: printf("This number is too large.\n");
            break;

        default:
        break;
    }
}

void printSymbolTable()
{
    int i;
    printf("\nSymbolTable\n");

    for(i = 0; i < numSymbols; i++)
    {
        printf("Kind %d, Name %s\n", symbol_table[i].kind, symbol_table[i].name);
    }
}

void printGeneratedCode(){
    int i;
    printf("\nGenerated Code\n");

    for(i = 0; i < cx; i++)
    {
        printf("%s %d %d\n", instructions[codeStack[i].op], codeStack[i].l, codeStack[i].m);
    }

    printf("\n");
}

char* typeToLexeme(int type)
{
	switch(type)
	{
	case nulsym:
		return "\0";

	case identsym:
		return NULL;

	case numbersym:
		return NULL;

	case plussym:
		return "+";

	case minussym:
		return "-";

	case multsym:
		return "*";

	case slashsym:
		return "/";

	case oddsym:
		return "odd";
		break;

	case eqlsym:
		return "=";

	case neqsym:
		return "<>";

	case lessym:
		return "<";

	case leqsym:
		return "<=";

	case gtrsym:
		return ">";

	case geqsym:
		return ">=";

	case lparentsym:
		return "(";

	case rparentsym:
		return ")";

	case commasym:
		return ",";

	case semicolonsym:
		return ";";

	case periodsym:
		return ".";

	case becomessym:
		return ":=";

	case beginsym:
		return "begin";

	case endsym:
		return "end";

	case ifsym:
		return "if";

	case thensym:
		return "then";

	case whilesym:
		return "while";

	case dosym:
		return "do";

	case callsym:
		return "call";

	case constsym:
		return "const";

	case intsym:
		return "int";

	case procsym:
		return "procedure";

	case writesym:
		return "write";

	case readsym:
		return "read";

	case elsesym:
		return "else";
	}

	return "Error: token type not found";
}

void updateTable(symbol temp){
        int i = 0;
        for(i = 0 ; i < numSymbols; i++){
                if(strcmp(temp.name, symbol_table[i].name) == 0){
                        symbol_table[i].value = temp.value;
                }
        }
}

// Prints the lexeme list and symbolic representation of tokens
void printLexemeList(){
	int i;
	printf("\nLexeme List\n");
	for(i = 0; i < h-1; i++){
		if(nameRec[i].hasValue == TRUE)
			printf("%d %d|", nameRec[i].kind, nameRec[i].value);
		else if(nameRec[i].kind == identsym)
			printf("%d %s|", nameRec[i].kind, nameRec[i].name);
		else
			printf("%d|", nameRec[i].kind);
	}
	printf("\n");

	i = 0;
	printf("\nSymbolic Representation\n");

	for( i = 0; i < h-1; i ++){
		if(nameRec[i].hasValue == TRUE)
			printf("%s.%d ", symbolesName[nameRec[i].kind], nameRec[i].value);
		else if(nameRec[i].kind == identsym)
			printf("%s.%s ", symbolesName[identsym], nameRec[i].name);
		else
			printf("%s ", symbolesName[nameRec[i].kind]);
	}
}

void printLexemeTable(){
    int i;
    printf("\n   Lexeme  token type\n");

    for( i = 0; i < h-1; i++){
        if(nameRec[i].hasValue == TRUE)
            printf("%9d %8d\n", nameRec[i].value, nameRec[i].kind);
        else
            printf("%9s %8d\n", nameRec[i].name, nameRec[i].kind);
        }

}

int printErrors(){
    int i, hasErrors = FALSE;

    for( i = 0; i < ERRMAX; i++){
        if(errors[i] > 0)
            hasErrors = TRUE;
    }

    for( i = 0; i < ERRMAX; i++){
        if(i == VARERR){
            printf("\n\nThere where %d Variable(s) errors\n", errors[i]);
        }
        else if(i == NUMERR){
            printf("There where %d Number(s) that where too long\n", errors[i]);
        }
        else if(i == VARLENERR){
            printf("There where %d Variable(s) that where too long\n", errors[i]);
        }
        else if(i == SYMBERR){
                printf("There where %d foreign symbole(s)\n", errors[i]);
        }
    }

    if(hasErrors == TRUE)
        return TRUE;
    else
        return FALSE;
}



